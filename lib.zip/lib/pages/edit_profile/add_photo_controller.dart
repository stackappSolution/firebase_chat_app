import 'package:get/get.dart';

class AddPhotoController extends GetxController{


}