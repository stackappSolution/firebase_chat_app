import 'package:get/get.dart';

class EditProfileNameController extends GetxController{

}