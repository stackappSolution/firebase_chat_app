import 'package:get/get.dart';

class EditProfileAboutController extends GetxController {}
