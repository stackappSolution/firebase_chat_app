import 'package:flutter/material.dart';

import 'package:signal/controller/edit_profile_controller.dart';

import 'edit_profile_screen.dart';

class EditProfileViewModel {
  EditProfileScreen? editProfileScreen;
  EditProfileController? editProfileController;

  EditProfileViewModel(this.editProfileScreen);

  void aboutTap(BuildContext context) {}

  void editPhotoTap() {}



}