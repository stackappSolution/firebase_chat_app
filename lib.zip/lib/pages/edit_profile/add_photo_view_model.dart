import 'package:signal/pages/edit_profile/add_photo_screen.dart';

class AddPhotoViewModel{

  AddPhotoScreen? addPhotoScreen;
  AddPhotoViewModel(this.addPhotoScreen);
}