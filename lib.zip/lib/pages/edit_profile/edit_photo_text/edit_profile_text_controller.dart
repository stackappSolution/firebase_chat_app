import 'package:get/get.dart';

class EditProfileTextController extends GetxController {}
