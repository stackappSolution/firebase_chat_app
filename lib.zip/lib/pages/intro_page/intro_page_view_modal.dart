

class IntroPageViewModal {
  String string = '';
 bool isConnected = false;

}
