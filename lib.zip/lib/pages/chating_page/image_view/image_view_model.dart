

import 'package:signal/pages/chating_page/image_view/image_view.dart';

class ImageViewModel{

  ImageView? imageView;
  Map<String,dynamic> arguments={};
  String? imageUrl;
  ImageViewModel(this.imageView);

}