import 'package:get/get.dart';
import 'package:signal/routes/routes_helper.dart';

goToIntroPage() {
  Get.toNamed(RouteHelper.getIntroScreen());
}

goToSignInPage() {
  Get.offAllNamed(RouteHelper.getSignInPage());
}

goToVerifyPage({required String phonenumber, verificationId, selectedCountry}) {
  Get.toNamed(RouteHelper.getVerifyOtpPage(), parameters: {
    "phoneNo": phonenumber,
    "verificationId": verificationId,
    "selectedCountry": selectedCountry.toString(),
  }, );
}

goToProfilePage() {
  Get.toNamed(RouteHelper.getProfileScreen());
}

goToSettingPage() {
  Get.toNamed(RouteHelper.getSettingScreen());
}

goToHomeScreen() {
  Get.toNamed(RouteHelper.getHomeScreen());
}

goToChattingPage() {
  Get.toNamed(RouteHelper.getChattingScreen());
}

goToAddPhotoScreen() {
  Get.toNamed(RouteHelper.getAddPhotoScreen());
}

goToAccountScreen() {
  Get.toNamed(RouteHelper.getAccountScreen());
}

goToPinSettingScreen() {
  Get.toNamed(RouteHelper.getChangePinScreen());
}

goToAppearanceScreen() {
  Get.toNamed(RouteHelper.getAppearanceScreen());
}

goToAdvancePinSettingScreen() {
  Get.toNamed(RouteHelper.getAdvancePinSettingScreen());
}

goToChangePhoneScreen() {
  Get.toNamed(RouteHelper.getChangePhoneScreen());
}

goToIntroScreen() {
  Get.toNamed(RouteHelper.getIntroScreen());
}

goToChatingScreen() {
  Get.toNamed(RouteHelper.getChattingScreen());
}

goToNewMessageScreen() {
  Get.toNamed(RouteHelper.getNewMessageScreen());
}
