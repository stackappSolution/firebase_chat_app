import 'package:get/get.dart';

class AppearanceController extends GetxController{

}