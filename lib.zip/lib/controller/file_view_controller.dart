import 'package:get/get.dart';

class FileViewControllers extends GetxController{

}