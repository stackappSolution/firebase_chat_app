import 'package:get/get.dart';

class VideosPlayerController extends GetxController{

}