import 'package:get/get_state_manager/src/simple/get_controllers.dart';

class SetPinController extends GetxController {}

class EnterPinController extends GetxController {}
