import 'package:get/get.dart';

class VerifyOtpController extends GetxController{

}