import 'package:get/get.dart';

class ProfileController extends GetxController{


}