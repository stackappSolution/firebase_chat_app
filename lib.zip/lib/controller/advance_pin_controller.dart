import 'package:get/get.dart';

class AdvancePinController extends GetxController{


}