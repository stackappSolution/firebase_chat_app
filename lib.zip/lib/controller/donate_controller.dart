import 'package:get/get.dart';

class DonateController extends GetxController{

}