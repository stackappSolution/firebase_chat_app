import 'package:get/get.dart';

class AccountController extends GetxController{

}