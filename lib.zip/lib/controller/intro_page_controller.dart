import 'package:get/get.dart';

import '../pages/intro_page/intro_page_view_modal.dart';

class IntroPageController extends GetxController {
  IntroPageViewModal introPageViewModal = IntroPageViewModal();
}
