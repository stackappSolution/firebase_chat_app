import 'package:get/get.dart';

class ChatProfileController extends GetxController{

}