import 'package:get/get.dart';

class InviteController extends GetxController{

}