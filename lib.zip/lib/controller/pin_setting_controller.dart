import 'package:get/get.dart';

class PinSettingController extends GetxController{


}