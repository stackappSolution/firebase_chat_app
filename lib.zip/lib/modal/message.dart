class Message {
  final String messages;
   bool isSender;
  final DateTime messageTimestamps;

  Message({
    required this.messages,
    required this.isSender,
    required this.messageTimestamps,
  });
}
